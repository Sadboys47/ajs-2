#𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] 𝙋.𝙆_𝘽𝙊𝙏𝙎 update 09-12-2020 id line=resdolly_zonk
#Thank For Aki DEVAN ,Ben,Igo,Dzul DK
#Thank for °™ᴀʟɪᴘ•GRIND KILLER
#Thank for ELFOX
#Supported by Babysha,dira,onay,padel,firman
#𝐁𝐓𝐑 𝐟𝐚𝐦𝐢𝐥𝐲[BONE TO REBORN] Ibal v2™ & friend
#𝐌𝐨𝐫𝐩𝐡𝐢𝐧𝐞𝐁𝐨𝐭𝐬
#Thank  For Greet sebagian emang dari sana 😂
#all family famz kebotan
import pantek
from pantek import *
from akad.ttypes import *
from datetime import datetime
import pytz, pafy, null, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, codecs, tweepy, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
from time import sleep
from zalgo_text import zalgo
from threading import Thread,Event
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
from tmp.Instagram import InstagramScraper
from Naked.toolshed.shell import execute_js 
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest


botStart = time.time()
msg_dict = {}
msg_dict1 = {}

#======Login Via Email Bagi Kalian Yg gk tau apa itu Token===================
dollypk = LINE("@gmail.com","pw")
dollypk.log("Auth Token : " + str(dollypk.authToken))

diravio = LINE("@gmail.com","pw")
diravio.log("Auth Token : " + str(diravio.authToken))

oepoll = OEPoll(dollypk)
call = dollypk
print ("LOGIN READY ")
print ("PROSES")
print ("︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ ")
print ("======1%\n=======50%\n=========100%")
print (" ᴛʜᴀɴᴋs ᴛᴏ ᴀʟʟᴀʜ sᴡᴛ ")
print (" ᴛʜᴀɴᴋs ᴛᴏ ᴘʏ³ ")
print (" ᴋᴇᴇᴘ sᴛᴀʏ ᴀɴᴅ ʀᴜʟʟᴇs ")
print ("\n\
= = = = = = = = = = = =        =====               === \n\
= = = = = = = = = = = = =      =====            === \n\
=======          ====== =      =====         === \n\
=======           ====== =     =====      ===\n\
=======           =======      =====    === \n\
=======           ======       ===== ===\n\
=================              ===== ===\n\
================               =====     ===\n\
=======                        =====      ===  \n\
=======                        =====         ===\n\
=======                        =====           ===\n\
=======                        =====             === \n")
print("LOGIN SUKSES")
print ("BOT AJS SIAP DI GUNAKAN\n   𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] 𝙋.𝙆_𝘽𝙊𝙏𝙎 \n\n")
#====mid kalian ya dan mid induk nya================================
creator = ["mid"]   #mid creator=info id line resdolly_zonk pc aja saudara kalau aktip fast kok
owner = ["mid"]  #mid owner
admin = ["mid"]   #mid admin

mid = dollypk.profile.mid
mid = dollypk.getProfile().mid
mid1 = diravio.getProfile().mid
bot = [dollypk]
pkbots = [mid,mid1]
#========================================
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "comment":"Coment by ︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ \n Creator line.me/ti/p/~resdolly_zonk ",
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    'autoJoin':True,
    'autoAdd':True,
    'leaveMsg':True,
    'left':True,
    'pantekQr':True,
    'pantekKick':True,
    'pantekKick1':True,
    'pantekjs':True,
    'staffJs':True,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":False,
    "Mentionkick":False,
    "welcomeOn":True,
    "sticker":False,
    "selfbot":True,
    "likeOn":False,
    'autoBlock':False,
    "unsend":True,
    "arespon":True,
    "mention1":True,
    "Respontag":"Jangan Tag gw bangsat",
    "welcome":"Kam Anak anjing",
    "message":"Yaelah lu ngpain",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

with open('dira.json', 'r') as fp:
    creator = json.load(fp)
with open('babysha.json', 'r') as fp:
    owner = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "╭──[Daftar Setan {}]──\n├ ".format(str(len(mid)))
        arr = []
        no = 1
        for i in mid:
            mention = "@dollypk\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "├ "
            else:
                try:
                    textx += "╰──[FvC3K]──".format(str(dollypk.getGroup(to).name))
                except:
                    pass
        dollypk.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        dollypk.sendMessage(to, "[ ɪɴғᴏ ] ᴇʀᴏʀ :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@dollypk\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += settings["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n???[ {} ]".format(str(dollypk.getGroup(to).name))
                except:
                    no = "\n???[ Success ]"
        dollypk.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = dollypk.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += "welcome"
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n???[ {} ]".format(str(dollypk.getGroup(to).name))
                except:
                    no = "\n???[ Success ]"
    except Exception as error:
        dollypk.sendMessage(to)

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Member Keluar「{}」\nByee  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = dollypk.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leftmsg"]+"\nDari group "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(aditmadzs.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
        dollypk.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
        
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd.startswith('ex\n'):
      if sender in dollypk:
        try:
            sep = text.split('\n')
            pantek = text.replace(sep[0] + '\n','')
            f = open('exec.txt', 'w')
            sys.stdout = f
            print(' ')
            exec(pantek)
            print('\n%s' % str(datetime.now()))
            f.close()
            sys.stdout = sys.__stdout__
            with open('exec.txt','r') as r:
                txt = r.read()
            dollypk.sendMessage(to, txt)
        except Exception as e:
            pass
      else:
        dollypk.sendMessage(to, 'ᴀᴘᴀʟᴜ !')
    elif cmd.startswith('exc\n'):
      if sender in dollypk:
        sep = text.split('\n')
        pantek = text.replace(sep[0] + '\n','')
        if 'print' in pantek:
        	pantek = pantek.replace('print(','dollypk.sendExecMessage(to,')
        	exec(pantek)
        else:
        	exec(pantek)
      else:
        dollypk.sendMessage(to, 'Yaelah!')        

def logError(text):
    dollypk.log("[ Team BotS ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Makassar")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("errorLog.txt","a") as error:
        error.write("\n[{}] {}".format(str(time), text))
        
def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost
def sendTextTemplate(to, text):
    data = {
            "type": "flex",
            "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ ",
            "contents":{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "text",
            "text":  text,
            "size": "xs",
            "wrap": True,
            "weight": "regular",
            "offsetStart": "3px"
          }
        ],
        "margin": "xs",
        "spacing": "md",
        "backgroundColor": "#00FFFF"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎",
            "align": "center",
            "size": "xs"
          }
        ],
        "paddingAll": "2px",
        "backgroundColor": "#000000",
        "margin": "xs"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#00FFFF",
    "cornerRadius": "10px",
    "spacing": "xs"
  },
  "styles": {
    "body": {
      "backgroundColor": "#00FFFF"
    }
  }
}
}
    dollypk.postTemplate(to, data)
 
def sendTextTemplate8(to, text):
    data = {
                                "type": "flex",
                                "altText": "{} ︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ".format(dollypk.getProfile().displayName),
                                "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "md",
            "weight": "bold",
            "wrap": True,
            "color": "#40E0D0",
            "align": "center"
          },
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00008B"
    },
    "header": {
      "backgroundColor": "#00008B"
    }
  },  
  "hero": {
    "type": "image",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "url": "https://media.tenor.com/images/842c542426869f999afaeb7d8c7940b3/tenor.gif",
    "size": "full",
    "margin": "xl"
  },
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "ᴏᴡɴᴇʀ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#7CFC00",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      },
      {
        "type": "separator",
        "color": "#E5E4E2"
      },
      {
        "type": "text",
        "text": "ᴘᴇsᴀɴ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "action": {
          "type": "uri",
          "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=Order"
        },
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#F0F8FF",
        "align": "center"
      }
    ]
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendTextTemplate7(to, text):
    data = {
                                "type": "flex",
                                "altText": "{} ︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ".format(dollypk.getProfile().displayName),
                                "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "md",
            "weight": "bold",
            "wrap": True,
            "color": "#40E0D0",
            "align": "center"
          },
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00008B"
    },
    "header": {
      "backgroundColor": "#00008B"
    }
  },  
  "hero": {
    "type": "image",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "url": "https://media.giphy.com/media/NTj6PZtxqt6U91ksRZ/giphy.gif",
    "size": "full",
    "margin": "xl"
  },
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "ᴏᴡɴᴇʀ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#7CFC00",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~antates_zonk"
        },
        "align": "center"
      },
      {
        "type": "separator",
        "color": "#E5E4E2"
      },
      {
        "type": "text",
        "text": "ᴘᴇsᴀɴ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#F0F8FF",
        "align": "center"
      }
    ]
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendTextTemplate6(to, text):
    data = {
                                "type": "flex",
                                "altText": "{} ︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ".format(dollypk.getProfile().displayName),
                                "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "md",
            "weight": "bold",
            "wrap": True,
            "color": "#40E0D0",
            "align": "center"
          },
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00008B"
    },
    "header": {
      "backgroundColor": "#00008B"
    }
  },  
  "hero": {
    "type": "image",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "url": "https://media.giphy.com/media/nbBbfmBVnuIYZ5itAc/giphy.gif",
    "size": "full",
    "margin": "xl"
  },
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "ᴏᴡɴᴇʀ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#7CFC00",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      },
      {
        "type": "separator",
        "color": "#E5E4E2"
      },
      {
        "type": "text",
        "text": "ᴘᴇsᴀɴ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#F0F8FF",
        "align": "center"
      }
    ]
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendTextTemplate4(to, text):
    data = {
                                "type": "flex",
                                "altText": "{} ︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ".format(dollypk.getProfile().displayName),
                                "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "md",
            "weight": "bold",
            "wrap": True,
            "color": "#40E0D0",
            "align": "center"
          },
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00008B"
    },
    "header": {
      "backgroundColor": "#00008B"
    }
  },  
  "hero": {
    "type": "image",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "url": "https://media0.giphy.com/media/xVxio2tNLAM5q/200w.webp?cid=19f5b51a5c44951d4b47664273e6c074",
    "size": "full",
    "margin": "xl"
  },
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "ᴏᴡɴᴇʀ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#7CFC00",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      },
      {
        "type": "separator",
        "color": "#E5E4E2"
      },
      {
        "type": "text",
        "text": "ᴘᴇsᴀɴ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#F0F8FF",
        "align": "center"
      }
    ]
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendTextTemplate5(to, text):
    data = {
            "type": "flex",
            "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
            "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "sm",
            "weight": "bold",
            "wrap": True,
            "color": "#F0F8FF"
          }
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00008B"
    },
    "header": {
      "backgroundColor": "#00008B"
    }
  },  
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "sᴇᴇ ʏᴏᴜ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "sᴏᴜɴᴅᴄʟᴏᴜᴅ",
        "size": "md",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "align": "center"
      }
    ]
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendTextTemplate1(to, text):
    data = {
                "type": "template",
                "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
                "contents": {
                    "type": "bubble",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                               "text": text,
                               "size": "sm",
                               "margin": "none",
                               "color": "#8B008B",
                               "wrap": True,
                               "weight": "regular",
                               "type": "text"
                            }
                        ]
                    }
                }
            }
    dollypk.postTemplate(to, data)
    
def sendTextTemplate2(to, text):
    data = {
            "type": "flex",
            "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
            "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#0000CD"
    }
  },
  "type": "bubble",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "contents": [
              {
                "text": text,
                "size": "md",
                "margin": "none",
                "color": "#FFFF00",
                "wrap": True,
                "weight": "bold",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendTextTemplate3(to, text):
    data = {
            "type": "flex",
            "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
            "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "sm",
            "weight": "bold",
            "wrap": True,
            "color": "#00FF00"
          }
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00FFFF"
    },
    "header": {
      "backgroundColor": "#00FFFF"
    }
    },  
     "hero": {
     "type": "image",
     "aspectRatio": "20:13",
     "aspectMode": "cover",
     "url": "https://media.giphy.com/media/67pVlH3LSLDjTBikzf/giphy.gif",
     "size": "full",
     "margin": "xl"
  },  
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "ᴏᴡɴᴇʀ",
        "size": "xxl",
        "wrap": True,
        "weight": "bold",
        "color": "#000000",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/~resdolly_zonk"
        },
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
        "size": "md",
        "wrap": True,
        "weight": "bold",
        "color": "#000000",
        "align": "center"
      }
    ]
  }
}
}
    dollypk.postTemplate(to, data)
    
def sendStickerTemplate(to, text):
    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
    to = op.param1
    data = {
                          "type": "template",
                          "altText": "{} sent a sticker".format(dollypk.getProfile().displayName),
                          "template": {
                             "type": "image_carousel",
                             "columns": [
                              {
                                  "imageUrl": text,
                                  "size": "full", 
                                  "action": {
                                      "type": "uri",
                                      "uri": "http://line.me/ti/p/~resdolly_zonk"
           }                                                
 }
]
                          }
                      }
    
def sendStickerTemplate(to, text):
    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
    to = op.param1
    data = {
                          "type": "template",
                          "altText": "{} sent a sticker".format(dollypk.getProfile().displayName),
                          "template": {
                             "type": "image_carousel",
                             "columns": [
                              {
                                  "imageUrl": text,
                                  "size": "full", 
                                  "action": {
                                      "type": "uri",
                                      "uri": "http://line.me/ti/p/~resdolly_zonk"
           }                                                
 }
]
                          }
                      }
    dollypk.postTemplate(to, data)    
    
def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output mp3 {}'.format(link))
    try:
        dollypk.sendAudio(to, 'mp3')
        time.sleep(2)
        os.remove('mp3')
    except Exception as e:
        dollypk.sendMessage(to, '𝙋.𝙆°𝘽𝙊𝙏𝙎\nʟɪɴᴋ ᴀɴᴅᴀ sᴀʟᴀʜ')
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output mp4 {}'.format(link))
    try:
        dollypk.sendVideo(to, "mp4")
        time.sleep(2)
        os.remove('mp4')
    except Exception as e:
        dollypk.sendMessage(to, ' ᴇʀʀᴏʀ\nʟɪɴᴋ ᴀɴᴅᴀ sᴀʟᴀʜ', contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+dollypk.getContact(dollypk).pictureStatus, 'AGENT_NAME': 'ᴇʀʀᴏʀ', 'AGENT_LINK': 'https://line.me/ti/p/~hags'})

def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        babysha = "ʙᴏᴛ ᴀᴋᴛɪғ "
                        dollypk.sendMessage(tmp, babysha, {'AGENT_LINK': "https://line.me/ti/p/~bot71", 'AGENT_ICON': "http://klikuntung.com/images/messengers/line-logo.png", 'AGENT_NAME': "Detect Spam "})        
                    except Exception as error:
                        logError(error)

def delExpirev2():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        babysha = "ʙᴏᴛ ᴀᴋᴛɪғ"
                        dollypk.sendMessage(tmp, babysha, {'AGENT_LINK': "https://line.me/ti/p/~resdolly_zonk", 'AGENT_ICON': "http://klikuntung.com/images/messengers/line-logo.png", 'AGENT_NAME': "Detect Spam "})        
                    except Exception as error:
                        logError(error)    

def musik(to):
    contentMetadata={'previewUrl': "http://dl.profile.line-cdn.net/"+dollypk.getContact(mid).picturePath, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': dollypk.getContact(mid).statusMessage if dollypk.getContact(mid).statusMessage != '' else 'http://line.me/ti/p/~muhaziralwi', 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': dollypk.getContact(mid).displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.cl.cl/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.me.naver.jp/os/p/"+mid,'MSG_SENDER_NAME':  dollypk.getContact(mid).displayName,}
    return dollypk.sendMessage(to, dollypk.getContact(mid).displayName, contentMetadata, 19)

def sendMention2(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@dollypk "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        dollypk.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        dollypk.sendImageWithURL(msg.to,image)
    except Exception as error:
        dollypk.sendMessage(to, "[ INFO ] Error :\n" + str(error))
    
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "┏━[𝙋.𝙆°𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎]━" + "\n" + \
                  "┃┍▪" + key + "pk in/out\n" + \
                  "┃┝▪"+ key + "pkstay\n" + \
                  "┃┝▪"+ key + "info「@」\n" + \
                  "┃┝▪"+ key + "restart\n" + \
                  "┃┝▪"+ key + "runtime\n" + \
                  "┃┝▪"+ key + "ajskick「@」\n" + \
                  "┃┝▪"+ key + "sp\n" + \
                  "┃┝▪"+ key + "kick\n" + \
                  "┃┝▪"+ key + "cabut (out )\n" + \
                  "┃┝▪"+ key + "ginfo\n" + \
                  "┃┝▪"+ key + "self ᴏɴ「@」\n" + \
                  "┃┝▪"+ key + "open\n" + \
                  "┃┝▪"+ key + "cloce\n" + \
                  "┃┝▪"+ key + "urlgrup\n" + \
                  "┃┝▪"+ key + "infogrup「ɴᴏ」\n" + \
                  "┃┝▪"+ key + "imfomem「ɴᴏ」\n" + \
                  "┃┝▪"+ key + "gruplist\n" + \
                  "┃┝▪"+ key + "updatefoto\n" + \
                  "┃┝▪"+ key + "updategrup\n" + \
                  "┃┝▪"+ key + "updatebot\n" + \
                  "┃┕"+ key + "cvp\n" + \
                  "┗━[ 𝙋.𝙆°𝘽𝙊𝙏𝙎☆2020 ]━"
    return helpMessage

def sett():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "┏━[𝙋.𝙆°𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎]━" + "\n" + \
                  "┃┍▪" + key + "blc\n" + \
                  "┃┝▪"+ key + "ban:on\n" + \
                  "┃┝▪"+ key + "unban:on\n" + \
                  "┃┝▪"+ key + "ban「@」\n" + \
                  "┃┝▪"+ key + "unban「@」\n" + \
                  "┃┝▪"+ key + "talkban「@」\n" + \
                  "┃┝▪"+ key + "untalkban「@」\n" + \
                  "┃┝▪"+ key + "talkban:on\n" + \
                  "┃┝▪"+ key + "untalkban:on\n" + \
                  "┃┝▪"+ key + "banlist\n" + \
                  "┃┝▪"+ key + "talkbanlist\n" + \
                  "┃┝▪"+ key + "clearban\n" + \
                  "┃┕"+ key + "refresh\n" + \
                  "┗━[ 𝙋.𝙆°𝘽𝙊𝙏𝙎☆2020 ]━"
    return helpMessage1

def bot(op):
    global time
    global ast
    global groupParam
    try:   
            
        if op.type == 11:
            if wait["pantekQr"] == True:
                try:
                    if dollypk.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                            dollypk.reissueGroupTicket(op.param1)
                            pkteam = dollypk.getGroup(op.param1)
                            pkteam.preventedJoinByTicket = True
                            Ticket = dollypk.reissueGroupTicket(op.param1)
                            dollypk.kickoutFromGroup(op.param1,[op.param2])
                            dollypk.updateGroup(pkteam)                           
                except:
                    pass
                    
        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                        dollypk.acceptGroupInvitation(op.param1)
                        ginfo = dollypk.getGroup(op.param1)
                        dollypk.leaveGroup(op.param1)
                    else:
                        dollypk.acceptGroupInvitation(op.param1)
                        ginfo = dollypk.getGroup(op.param1)
                  
        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                        dollypk.acceptGroupInvitation(op.param1)
                        ginfo = dollypk.getGroup(op.param1)
                        sendTextTemplate(op.param1,"Thank for invite " +str(ginfo.name))
                    else:
                        dollypk.acceptGroupInvitation(op.param1)
                        ginfo = dollypk.getGroup(op.param1)
                        sendTextTemplate(op.param1,"Thank For Invite" + str(ginfo.name))
                        
        if op.type == 19:
            if wait["pantekKick"] == True:
                if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    try:
                        dollypk.kickoutFromGroup(op.param1,[op.param2])
                        dollypk.findAndAddContactsByMid(admin)
                        dollypk.inviteIntoGroup(op.param1,[admin])
                    except:
                        pass
                        
        if op.type == 19:
            if wait["pantekKick1"] == True:
                if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    try:
                        diravio.kickoutFromGroup(op.param1,[op.param2])
                        diravio.findAndAddContactsByMid(mid)
                        diravio.inviteIntoGroup(op.param1,[mid])
                    except:
                        pass
        
        if op.type == 32:
            if wait["pantekjs"] == True:
                if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            dollypk.kickoutFromGroup(op.param1,[op.param2])
                            dollypk.inviteIntoGroup(op.param1,[mid1])
                    except:
                        pass
            return
                        

        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                dollypk.kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 15:
            if wait["leaveMsg"] == True:
                ginfo = dollypk.getGroup(op.param1)
                leaveMembers(op.param1, [op.param2])
                contact = dollypk.getContact(op.param2)
                sendTextTemplate(msg.to, "Baperan amat lu nyet")

              
        if op.type == 17:
            if wait["welcomeOn"] == True:
                ginfo = dollypk.getGroup(op.param1)
                welcomeMembers(op.param1, [op.param2])
                contact = dollypk.getContact(op.param2)
                sendTextTemplate(msg.to, "welcome anak anjing")

        if op.type == 5:
            print ("[ 5 ] ɴᴏᴛɪғɪᴇᴅ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴄᴏɴᴛᴀᴄᴛ")
            if wait["autoBlock"] == True:
                dollypk.blockContact(op.param1)
                dollypk.sendMessage(op.param1, wait["sorry nyet auto block aktip"])
                
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in pkbots and op.param2 not in creator and op.param2 not in admin:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        dollypk.sendMessage(op.param1, wait["message"])
                
        if op.type == 19:
            if mid in op.param3:
                if op.param2 in pkbots:
                    pass
                if op.param2 in creator:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        diravio.acceptGroupInvitation(op.param1)
                        diravio.kickoutFromGroup(op.param1,[op.param2])
                        diravio.findAndAddContactsByMid(mid)
                        diravio.inviteIntoGroup(op.param1,[mid])
                        dollypk.acceptGroupInvitation(op.param1)
                        diravio.leaveGroup(op.param1)
                        dollypk.inviteIntoGroup(op.param1,[mid1])
                    except:
                        pass
            
        if op.type == 19:
            if admin in op.param3:
                if op.param2 in pkbots:
                    pass
                if op.param2 in creator:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        dollypk.kickoutFromGroup(op.param1,[op.param2])
                        dollypk.inviteIntoGroup(op.param1,[admin])
                    except:
                        pass
                return
        if op.type == 55:
            try:
                if op.param1 in Setmain["RAreadPoint"]:
                   if op.param2 in Setmain["RAreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["RAreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                dollypk.kickoutFromGroup(op.param1,[op.param2])
                dollypk.cancelGroupInvitation(op.param1,[op.param3])
            else:
                pass

        
        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = dollypk.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = dollypk.getContact(op.param2)
                        data = {
                                "type": "flex",
                                "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": str(dollypk.getProfileCoverURL(op.param2)),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(dollypk.getContact(op.param2).displayName),
                "color": "#00FFFF",
                "size": "xs",
                "margin": "xxl",
                "style": "normal",
                "decoration": "underline",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "margin": "none",
            "width": "220px",
            "offsetTop": "215px",
            "offsetStart": "33px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(dollypk.getContact(op.param2).pictureStatus),
                "aspectMode": "cover",
                "position": "absolute",
                "size": "full"
              }
            ],
            "width": "154px",
            "height": "150px",
            "cornerRadius": "100px",
            "position": "absolute",
            "borderWidth": "3px",
            "borderColor": "#00FFFF",
            "offsetBottom": "40px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
                "size": "sm",
                "color": "#00FFFF",
                "weight": "bold"
              }
            ],
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/Jv7S08h/1577440250141.jpg",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "offsetStart": "5px",
            "offsetBottom": "2px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "position": "relative",
        "borderColor": "#00FFFF"
      }
    }
  ]
}
}
                        dollypk.postTemplate(op.param1, data)
                
        if op.type == 25 or op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in pkbots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          dollypk.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              dollypk.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              dollypk.kickoutFromGroup(msg.to, [msg._from])
                                        
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   contact = dollypk.getContact(msg._from)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in pkbots:
                           sendTextTemplate(msg.to, wait["Respontag"])
                           break
                           
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in pkbots:
                           dollypk.mentiontag(msg.to,[msg._from])
                           dollypk.sendMessage(msg.to, "Jangan Tag anjeng")
                           dollypk.kickoutFromGroup(msg.to, [msg._from])
                           break
                           
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["arespon"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   lists = []
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           contact = dollypk.getContact(msg._from)
                           dollypk.sendImageWithURL(msg._from, "http://dl.profile.line-cdn.net{}".format(contact.picturePath))
                           sendMention1(sender, "Lu Mulu", [sender])
                           break
                           
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    dollypk.sendMessage(msg.to,"「ᴄᴇᴋ ɪᴅ sᴛɪᴄᴋᴇʀ」\nsᴛᴋɪᴅ : " + msg.contentMetadata["STKID"] + "\nsᴛᴋᴘᴋɢɪᴅ : " + msg.contentMetadata["STKPKGID"] + "\nsᴛᴋᴠᴇʀ : " + msg.contentMetadata["STKVER"]+ "\n\n「ʟɪɴᴋ sᴛɪᴄᴋᴇʀ」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    dollypk.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = dollypk.getContact(msg.contentMetadata["mid"])
                        path = dollypk.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        dollypk.sendMessage(msg.to,"ɴᴀᴍᴀ : " + msg.contentMetadata["displayName"] + "\nᴍɪᴅ : " + msg.contentMetadata["mid"] + "\nsᴛᴀᴛᴜs ᴍsɢ : " + contact.statusMessage + "\nᴘɪᴄᴛᴜʀᴇ ᴜʀʟ : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        dollypk.sendImageWithURL(msg.to, image)
                        
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 16:
                        url = msg.contentMetadata["postEndUrl"]
                        dollypk.likePost(url[25:58], url[66:], likeType=1004)
                        dollypk.createComment(url[25:58], url[66:], settings["comment"])
                        print ("ᴀᴜᴛᴏ ʟɪᴋᴇ ")
                        sendTextTemplate(msg.to," ᴀᴜᴛᴏ ʟɪᴋᴇ ")
                        settings["likeOn"] = False
        if op.type == 25 or op.type == 26:	     
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    sendTextTemplate(msg.to,"sᴛᴋɪᴅ : " + msg.contentMetadata["STKID"] + "\nsᴛᴋᴘᴋɢɪᴅ : " + msg.contentMetadata["STKPKGID"] + "\nsᴛᴋᴠᴇʀ : " + msg.contentMetadata["STKVER"]+ "\n\n「ʟɪɴᴋ sᴛɪᴄᴋᴇʀ」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    dollypk.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = dollypk.getContact(msg.contentMetadata["mid"])
                        path = dollypk.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        sendTextTemplate(msg.to,"ɴᴀᴍᴀ : " + msg.contentMetadata["displayName"] + "\nᴍɪᴅ : " + msg.contentMetadata["mid"] + "\nsᴛᴀᴛᴜs ᴍsɢ : " + contact.statusMessage + "\nᴘɪᴄᴛᴜʀᴇ ᴜʀʟ: http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        dollypk.sendImageWithURL(msg.to, image)
                         
               if msg.contentType == 2:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilevid"]:
                            settings["ChangeVideoProfilePicture"][msg._from] = True
                            del settings["ChangeVideoProfilevid"][msg._from]
                            dollypk.downloadObjectMsg(msg_id,'path','video.mp4')
                            sendTextTemplate(msg.to,"sᴇɴᴅ ɢᴀᴍʙᴀʀɴʏᴀ...")
                            
               if msg.contentType == 1:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilePicture"]:
                            del settings["ChangeVideoProfilePicture"][msg._from]
                            dollypk.downloadObjectMsg(msg_id,'path','image.jpg')
                            dollypk.nadyacantikimut('video.mp4','image.jpg')
                            sendTextTemplate(msg.to,"ɢᴀɴᴛɪ ᴠɪᴅɪᴏ ᴘʀᴏғɪʟ ᴅᴏɴᴇ!!!")
#=======ADD Bots==========================
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in pkbots:
                        sendTextTemplate(msg.to,"▪sᴜᴅᴀʜ ᴊᴀᴅɪ ʙᴏᴛ")
                        wait["addbots"] = True
                    else:
                        pkbots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ᴀɴɢɢᴏᴛᴀ ʙᴏᴛ")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in pkbots:
                        pkbots.remove(msg.contentMetadata["mid"])
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ᴀɴɢɢᴏᴛᴀ ʙᴏᴛ")
                    else:
                        wait["dellbots"] = True
                        sendTextTemplate(msg.to,"▪ɪᴛᴜ ʙᴜᴋᴀɴ ᴀɴɢɢᴏᴛᴀ ʙᴏᴛ")
                        
#=========== ADD STAFF==========================
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        dollypk.sendMessage(msg.to,"▪sᴜᴅᴀʜ ᴊᴀᴅɪ sᴛᴀғғ")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ sᴛᴀғғ")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs sᴛᴀғғ")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        sendTextTemplate(msg.to,"▪ɪᴛᴜ ʙᴜᴋᴀɴ sᴛᴀғғ")
#=========ADD ADMIN==========================
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        sendTextTemplate(msg.to,"▪ɪᴛᴜ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜ ᴀᴅᴍɪɴ")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ᴀᴅᴍɪɴ")
                    else:
                        wait["delladmin"] = True
                        sendTextTemplate(msg.to,"▪ɪᴛᴜ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ")
#===========ADD BLACKLIST==========================
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        sendTextTemplate(msg.to,"▪sᴜᴅᴀʜ ᴀᴅᴀ ᴅɪ ʙʟᴀᴄᴋʟɪsᴛ")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜ ʙʟᴀᴄᴋʟɪsᴛ ᴜsᴇʀ")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ʙʟᴀᴄᴋʟɪsᴛ ᴜsᴇʀ")
                    else:
                        wait["dblacklist"] = True
                        sendTextTemplate(msg.to,"▪ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙʟᴀᴄᴋʟɪsᴛ")

                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        sendTextTemplate(msg.to,"▪sᴜᴅᴀʜ ᴀᴅᴀ ᴅɪ ᴛᴀʟᴋʙᴀɴ")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ᴛᴀʟᴋʙᴀɴ ᴜsᴇʀ")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                         sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ᴛᴀʟᴋʙᴀɴ ᴜsᴇʀ")
                    else:
                        wait["Talkdblacklist"] = True
                        sendTextTemplate(msg.to,"▪ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅɪ ᴛᴀʟᴋʙᴀɴ")
#========UPDATE FOTO==========================
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = dollypk.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            sendTextTemplate(msg.to, "▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ɢᴀᴍʙᴀʀ")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = dollypk.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     dollypk.updateGroupPicture(msg.to, path)
                     sendTextTemplate(msg.to, "▪ᴅᴏɴᴇ ᴍᴇɴɢᴜʙᴀʜ ғᴏᴛᴏ ɢʀᴏᴜᴘ")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAfoto"]:
                            path = dollypk.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            dollypk.updateProfilePicture(path)
                            sendTextTemplate(msg.to,"▪ғᴏᴛᴏ ᴅᴏɴᴇ ᴅɪ ʀᴜʙᴀʜ")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        dollypk.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)                        
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               sendTextTemplate(msg.to, str(helpMessage))                        
                        if cmd == "help2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = sett()
                               sendTextTemplate(msg.to, str(helpMessage1))
                                                                                       
                        if cmd == "self on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                sendTextTemplate(msg.to, "▪ᴛᴇᴍᴘʟᴀᴛᴇ ᴀᴋᴛɪғ ")
 
                        elif cmd == "self off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                sendTextTemplate(msg.to, "bot off")
                                
                        elif cmd == "me":
                                contact = dollypk.getProfile()
                                mids = [contact.mid]
                                status = dollypk.getContact(sender)                               	
                                data = {
                                        "type": "flex",
                                        "altText": "︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
                                        "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "hero": {
        "type": "image",
        "url": "https://obs.line-scdn.net/{}".format(dollypk.getContact(sender).pictureStatus),
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "320:213"
      },
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(status.displayName),
            "weight": "bold",
            "size": "xs",
            "wrap": True
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(status.statusMessage),
                "size": "xs",
                "color": "#000000",
                "wrap": True
              }
            ]
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "horizontal",
                "spacing": "xs",
                "contents": [
                  {
                    "type": "text",
                    "text": "          𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
                    "wrap": True,
                    "color": "#000000",
                    "size": "xs",
                    "offsetTop": "0px"
                  }
                ]
              }
            ]
          }
        ],
        "spacing": "xs",
        "paddingAll": "13px"
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "hero": {
        "type": "image",
        "url": "https://i.ibb.co/Jv7S08h/1577440250141.jpg",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "320:213"
      },
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "ᴄʀᴇᴀᴛᴏʀ",
            "weight": "bold",
            "size": "sm",
            "wrap": True
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "text",
                "text": "𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] ",
                "size": "sm",
                "color": "#000000",
                "margin": "md",
                "flex": 0
              }
            ]
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "spacing": "sm",
                "contents": [
                  {
                    "type": "text",
                    "text": "          𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
                    "wrap": True,
                    "color": "#000000",
                    "size": "xs",
                    "flex": 5
                  }
                ]
              }
            ]
          }
        ],
        "spacing": "sm",
        "paddingAll": "13px"
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "hero": {
        "type": "image",
        "url": "https://i.ibb.co/Jv7S08h/1577440250141.jpg",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "320:213"
      },
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "ᴄʀᴇᴀᴛᴏʀ",
            "weight": "bold",
            "size": "sm"
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "text",
                "text": "𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] ",
                "size": "sm",
                "color": "#000000",
                "margin": "md",
                "flex": 0
              }
            ]
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "spacing": "sm",
                "contents": [
                  {
                    "type": "text",
                    "text": "          𝙋.𝙆°𝘽𝙊𝙏𝙎 ",
                    "wrap": True,
                    "color": "#000000",
                    "size": "xs",
                    "flex": 5
                  }
                ]
              }
            ]
          }
        ],
        "spacing": "sm",
        "paddingAll": "13px"
      }
    }
  ]
}
}
                                dollypk.postTemplate(to, data)
 
                        elif cmd == "setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "𝙋.𝙆 𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎\n"
                                if wait["sticker"] == True: md+="▪sᴛɪᴄᴋᴇʀ ᴏɴ\n"
                                else: md+="▪sᴛɪᴄᴋᴇʀ ᴏғғ\n"
                                if wait["left"] == True: md+="▪ʟᴇғᴛ ᴏɴ\n"
                                else: md+="▪ʟᴇғᴛ ᴏғғ\n"                        
                                if wait["contact"] == True: md+="▪ᴄᴏɴᴛᴀᴄᴛ ᴏɴ\n"
                                else: md+="▪ᴄᴏɴᴛᴀᴄᴛ ᴏғғ\n"
                                if wait["talkban"] == True: md+="▪ᴛᴀʟᴋʙᴀɴ ᴏɴ\n"
                                else: md+="▪ᴛᴀʟᴋʙᴀɴ ᴏғғ\n"
                                if wait["unsend"] == True: md+="▪ᴜɴsᴇɴᴅ ᴏɴ\n"
                                else: md+="▪ᴜɴsᴇɴᴅ ᴏғғ\n"
                                if wait["Mentionkick"] == True: md+="▪ɴᴏᴛᴀɢ ᴏɴ\n"
                                else: md+="▪ɴᴏᴛᴀɢ ᴏɴ\n"
                                if wait["detectMention"] == True: md+="▪ʀᴇsᴘᴏɴ ᴏɴ\n"
                                else: md+="▪ʀᴇsᴘᴏɴ ᴏɴ\n"
                                if wait["autoJoin"] == True: md+="▪ᴀᴜᴛᴏᴊᴏɪɴ ᴏɴ\n"
                                else: md+="▪ᴀᴜᴛᴏᴊᴏɪɴ ᴏғғ\n"
                                if wait["autoAdd"] == True: md+="▪ᴀᴜᴛᴏᴀᴅᴅ ᴏɴ\n"
                                else: md+="▪ᴀᴜᴛᴏᴀᴅᴅ ᴏɴ\n"
                                if msg.to in welcome: md+="▪ᴡᴇʟᴄᴏᴍᴇ ᴏɴ\n"
                                else: md+="▪ᴡᴇʟᴄᴏᴍᴇ ᴏғғ\n"
                                if wait["autoLeave"] == True: md+="▪ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴏɴ\n"
                                else: md+="▪ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴏғғ\n"
                                if msg.to in protectqr: md+="▪ᴘʀᴏᴛᴇᴄᴛᴜʀʟ ᴏɴ\n"
                                else: md+="▪ᴘʀᴏᴛᴇᴄᴛᴜʀʟ ᴏғғ\n"
                                if msg.to in protectjoin: md+="▪ᴘʀᴏᴛᴇᴄᴛᴊᴏɪɴ ᴏɴ\n"
                                else: md+="▪ᴘʀᴏᴛᴇᴄᴛᴊᴏɪɴ ᴏғғ\n"
                                if msg.to in protectkick: md+="▪ ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ ᴏɴ\n"
                                else: md+="▪ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ ᴏғғ\n"
                                if msg.to in protectcancel: md+="▪ᴘʀᴏᴛᴇᴄᴛᴄᴀɴᴄᴇʟ ᴏɴ\n"
                                else: md+="▪ᴘʀᴏᴛᴇᴄᴛᴄᴀɴᴄᴇʟ ᴏғғ\n"
                                sendTextTemplate(msg.to, md+"\nᴛᴀɴɢɢᴀʟ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nᴊᴀᴍ [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "creator" or text.lower() == 'owner':
                            if msg._from in admin:
                               dollypk.sendMessage(msg.to, "Ni Creator kami yang receh nya minta ampun")
                               dollypk.sendContact(to, "u3a4cc9a5d0da4077d7dc6cd4f405517c")

                        elif cmd == "about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                               dollypk.sendMessage(msg.to, "       𝙋.𝙆 𝙎𝙀𝙇𝙁𝘽𝙊𝙏𝙎 \n▪Protect ajs Bots\n▪Version Lupa\n▪Team=𝙋.𝙆 𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎\n▪Creator=𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲]\n\n       Supported by:\n•Aki Devan\n•Ben \n•IGO \n•ELFOX\n•𝐁𝐓𝐑 𝐟𝐚𝐦𝐢𝐥𝐲 Ibal & Friend\n•°™ᴀʟɪᴘ•GRIND KILLER\n•☆𝕱𝖆𝖒𝖟 𝖐𝖊𝖇𝖔𝖙𝖆𝖓☆\n\n         𝙋.𝙆_𝘽𝙊𝙏𝙎  2020\n")
                               dollypk.sendMessage(msg.to, "Info Bot Silahkan Chat Admin")
                               dollypk.sendContact(to, "u3a4cc9a5d0da4077d7dc6cd4f405517c")
                               dollypk.sendContact(to, "ue0730b00558542cf28a9256e57b308cc")                  
                               
                        elif cmd == "promo" or text.lower() == 'order':
                          if wait["selfbot"] == True:
                               dollypk.sendMessage(msg.to,"          𝙋.𝙆 𝙎𝙀𝙇𝙁𝘽𝙊𝙏𝙎 \n   ▪Open Order▪\n\n🔹️VPS CONOHA NON RENEW\n2 Core 1GB = 100k \n3 Core 2GB =200k\n4 Core 4GB = 360k \n\n🔹️VPS CONOHA RENEW\n2 Core 1GB =120k\n3 Core 2GB = 240k\n4 Core 4GB = 420k \n\n🔹️VPS LINODE \n1 Core 2GB = 50k \n2 Core 4GB = 100K \n4 Core 8GB = 200K \n6 Core 16GB = 350K\n\n            ☆Open Order☆\n▪script Bot cl = 200K\n▪script Selfbot only =150k\n▪script Self Template=400K\n         ☆Open Sewa/Rental☆\n▪Sewa Pro Go= 300k/7 Bot\n▪Nambah asis Pc aja\n▪Sewa pro python= Harga pc\n▪Sewa Protect Cl Bot= 25K/Bot\n\n▪Pembuatan Bot kuis=30K/Bulan\nSoal,Nick Bot Atas nama kalian\n\n▪Jasa Protect=50k/Room\nMenggunakan Pro Go[Golang] \n\n▪Token primery 5k/token\n▪1 nomer 1 token\n▪ Juga open gift tikel ya mslah harga selalu berubah\n\nminat ? tanya2? chat id di bawah\nline.me/ti/p/~mina59.")      
                               sendTextTemplate(msg.to,"Jika Berminat \nLangsung Hubungi Kami Ya \nTrima Kasih😊😊")
                                
#===============cmd ajs===========================                                
                        elif cmd == "pk in":
                            if msg._from in admin:
                                G = dollypk.getGroup(msg.to)
                                ginfo = dollypk.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                dollypk.updateGroup(G)
                                invsend = 0
                                Ticket = dollypk.reissueGroupTicket(msg.to)
                                diravio.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = diravio.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                diravio.updateGroup(G)
                                diravio.sendMessage(msg.to, "Boleh Rusuh Kah 😂")

                        elif cmd == "pk out":
                            if msg._from in admin:
                                G = diravio.getGroup(msg.to)
                                diravio.sendMessage(msg.to, "kena usir guys😱")
                                diravio.leaveGroup(msg.to)
                                    
                        elif cmd == "pkstay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = dollypk.getGroup(msg.to)
                                    dollypk.inviteIntoGroup(msg.to, [mid1])
                                    sendTextTemplate(msg.to,"[ ɢʀᴏᴜᴘ ] \n▪"+str(ginfo.name)+"\n stay nyet")
                                except:
                                    pass

                        elif "autoreject " in msg.text.lower():
                            xpesan = msg.text.lower()
                            xres = xpesan.replace("autoreject ","")
                            if xres == "off":
                                settings['autorejc'] = False
                                sendTextTemplate(msg.to,"ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ ᴏғғ ɢᴀᴋ ᴀᴍᴀɴ ᴅᴀᴅɪ sᴘᴀᴍ")
                            elif xres == "on":
                                settings['autorejc'] = True
                                sendTextTemplate(msg.to,"ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ ᴏɴ ᴀᴍᴀɴ ᴅᴀʀɪ sᴘᴀᴍ")
                        
                        elif text.lower() == "mid":
                               dollypk.sendMessage(msg.to, msg._from)
                               
                        elif text.lower() == "mymid":
                               dollypk.sendMessage(msg.to, msg._from)
                                  
                        elif cmd == ".me" or text.lower() == 'pme':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                msg.contentType = 13
                                msg.contentMetadata = {'mid': mid}
                                dollypk.sendContact(to, mid)

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = dollypk.getContact(key1)
                               dollypk.sendMessage(msg.to, "ɴᴀᴍᴀ : "+str(mi.displayName)+"\nᴍɪᴅ : " +key1)
                               dollypk.sendMessage(msg.to, None, contentMetadata={'u03addfbbbdb20585381383e5d173d28d': key1}, contentType=13)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = dollypk.getContact(key1)
                               sendTextTemplate(msg.to, "ɴᴀᴍᴀ : "+str(mi.displayName)+"\nᴍɪᴅ : " +key1+"\nsᴛᴀᴛᴜs ᴍsɢ"+str(mi.statusMessage))
                               dollypk.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(dollypk.getContact(key1)):
                                   dollypk.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   dollypk.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif text.lower() == "clearchat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   dollypk.removeAllMessages(op.param2)
                                   sendTextTemplate(msg.to,"▪ʜᴀᴘᴜs ᴄʜᴀᴛ ᴅᴏɴᴇ")
                               except:
                                   pass
                                   
                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendTextTemplate(msg.to, "▪ɢᴀɢᴀʟ ᴍᴇɴɢɢᴀɴᴛɪ ᴋᴇʏ")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   sendTextTemplate(msg.to, "▪sᴇᴛᴋᴇʏ\n▪ᴅɪ ɢᴀɴᴛɪ ᴊᴀᴅɪ「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               sendTextTemplate(msg.to, "▪sᴇᴛᴋᴇʏ\n▪ᴋᴇᴍʙᴀʟɪ ᴋᴇ ᴀᴡᴀʟ")

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪ᴡᴀɪᴛ....")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               sendTextTemplate(msg.to, "▪ᴅᴏɴᴇ ʀᴇsᴛᴀʀᴛ...")
                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "▪ʙᴏᴛ ᴀᴋᴛɪғ sᴇʟᴀᴍᴀ\n" +waktu(eltime)
                               sendTextTemplate(msg.to,bot)
                            
                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = dollypk.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "▪ᴛᴇʀᴛᴜᴛᴜᴘ"
                                    gTicket = "☆ᴛɪᴅᴀᴋ ᴀᴅᴀ"
                                else:
                                    gQr = "▪ᴛᴇʀʙᴜᴋᴀ"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(dollypk.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                sendTextTemplate(msg.to, "▪𝙋.𝙆°𝘽𝙊𝙏𝙎▪ɢʀᴜᴘ ɪɴғᴏ\n\n▪ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(G.name)+ "\n▪ɪᴅ ɢʀᴜᴘ : {}".format(G.id)+ "\n▪ᴘᴇᴍʙᴜᴀᴛ : {}".format(G.creator.displayName)+ "\n▪ᴡᴀᴋᴛᴜ ᴅɪ ʙᴜᴀᴛ : {}".format(str(timeCreated))+ "\n▪ᴊᴜᴍʟᴀʜ ᴀɴɢɢᴏᴛᴀ : {}".format(str(len(G.members)))+ "\n▪ᴊᴜᴍʟᴀʜ ᴘᴇɴᴅɪɴɢᴀɴ : {}".format(gPending)+ "\n▪ɢʀᴜᴘ ǫʀ : {}".format(gQr)+ "\n▪ɢʀᴜᴘ ᴛɪᴄᴋᴇᴛ : {}".format(gTicket))
                                dollypk.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                            except Exception as e:
                                sendTextTemplate(msg.to, str(e))

                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = dollypk.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = dollypk.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "▪ᴛɪᴅᴀᴋ ᴅɪ ᴛᴇᴍᴜᴋᴀɴ"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "▪ᴛᴇʀᴛᴜᴛᴜᴘ"
                                    gTicket = "☆ᴛɪᴅᴀᴋ ᴀᴅᴀ"
                                else:
                                    gQr = "▪ᴛᴇʀʙᴜᴋᴀ"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(dollypk.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "▪ᴄᴍᴅ ɢʀᴜᴘ ɪɴғᴏ▪\n"
                                ret_ += "\n▪ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(G.name)
                                ret_ += "\n▪ɪᴅ ɢʀᴜᴘ : {}".format(G.id)
                                ret_ += "\n▪ᴘᴇᴍʙᴜᴀᴛ : {}".format(gCreator)
                                ret_ += "\n▪ᴡᴀᴋᴛᴜ ᴅɪʙᴜᴀᴛ : {}".format(str(timeCreated))
                                ret_ += "\n▪ᴊᴜᴍʟᴀʜ ᴀɴɢɢᴏᴛᴀ : {}".format(str(len(G.members)))
                                ret_ += "\n▪ᴊᴜᴍʟᴀʜ ᴘᴇɴᴅɪɴɢᴀɴ : {}".format(gPending)
                                ret_ += "\n▪ɢʀᴜᴘ ǫʀ : {}".format(gQr)
                                ret_ += "\n▪ɢʀᴜᴘ ᴛɪᴄᴋᴇᴛ : {}".format(gTicket)
                                ret_ += ""
                                sendTextTemplate(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = dollypk.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = dollypk.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "▪"+ str(no) + ". " + mem.displayName
                                sendTextTemplate(to," ▪ɢʀᴜᴘ ɴᴀᴍᴇ : [ " + str(G.name) + " ]\n\n   [ʟɪsᴛ ᴀɴɢɢᴏᴛᴀ ]\n" + ret_ + "\n\n▪ᴛᴏᴛᴀʟ %i ᴀɴɢɢᴏᴛᴀ▪" % len(G.members))
                            except: 
                                pass

                        elif cmd == "friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = dollypk.getAllContactIds()
                               for i in gid:
                                   G = dollypk.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "☆"+ str(a) + ". " +G.displayName+ "\n"
                               dollypk.sendMessage(msg.to,"▪ɢʀᴏᴜᴘ ʟɪsᴛ▪\n│\n"+ma+"│\n▪ᴛᴏᴛᴀʟ"+str(len(gid))+"ɢʀᴏᴜᴘ▪")

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = dollypk.getGroupIdsJoined()
                               for i in gid:
                                   G = dollypk.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "☆"+ str(a) + ". " +G.name+ "\n"
                               dollypk.sendMessage(msg.to,"▪ɢʀᴏᴜᴘ ʟɪsᴛ▪\n│\n"+ma+"│\n▪ᴛᴏᴛᴀʟ"+str(len(gid))+"ɢʀᴏᴜᴘ▪")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = dollypk.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   dollypk.updateGroup(X)
                                   dollypk.sendMessage(msg.to, "▪ᴏᴘᴇɴ ᴜʀʟ")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = dollypk.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   dollypk.updateGroup(X)
                                   dollypk.sendMessage(msg.to, "▪ᴄʟᴏsᴇ ᴜʀʟ")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = dollypk.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      dollypk.updateGroup(x)
                                   gurl = dollypk.reissueGroupTicket(msg.to)
                                   dollypk.sendMessage(msg.to, "ɴᴀᴍᴀ : "+str(x.name)+ "\nᴜʀʟ ɢʀᴜᴘ : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                dollypk.sendMessage(msg.to,"Mana Sayang Foto Nya")

                        elif cmd == "updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                dollypk.sendMessage(msg.to,"Mana Sayang Foto Nya")
                                
                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["ChangeVideoProfilevid"][msg._from] = True
                                dollypk.sendMessage(msg.to,"Mana Sayang Video Nya")
                                
                        elif cmd.startswith("changedualurl: "):
                            if msg._from in admin:
                                sep = msg.text.split(" ")
                                url = msg.text.replace(sep[0] + " ","")                            
                                dollypk.downloadFileURL(url,'path','video.mp4')
                                settings["ChangeVideoProfilePicture"][msg._from] = True
                                dollypk.sendMessage(msg.to, "Kirim Buruan")
                                
                        elif cmd == "cp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                dollypk.sendMessage(msg.to,"Mana Sayang Foto Nya")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = dollypk.getProfile()
                                profile.displayName = string
                                dollypk.updateProfile(profile)
                                dollypk.sendMessage(msg.to,"Nama Baru  " + string + "")

#===========BOT UPDATE============#
                        elif cmd == "pepek" or text.lower() == 'mentionall':
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = dollypk.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                    s += 7
                                    txt += u'@Zero \n'
                                dollypk.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in pkbots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +dollypk.getContact(m_id).displayName + "\n"
                                sendTextTemplate(msg.to,"▪ʟɪsᴛ ʙᴏᴛ\n\n"+ma+"\n▪ᴛᴏᴛᴀʟ ʙᴏᴛ「%s」" %(str(len(pkbots))))

                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in creator:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +dollypk.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +dollypk.getContact(m_id).displayName + "\n"
                                sendTextTemplate(msg.to,"☆sᴜᴘᴇʀ ᴀᴅᴍɪɴ :\n"+ma+"\n☆ᴀᴅᴍɪɴ :\n"+mb+"\n☆ᴊᴜᴍʟᴀʜ ᴀᴅᴍɪɴ 「%s」☆" %(str(len(creator)+len(admin))))

                        elif cmd == "cekpro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +dollypk.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +dollypk.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +dollypk.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +dollypk.getGroup(group).name + "\n"
                                sendTextTemplate(msg.to,"▪ᴘʀᴏ ɢʀᴏᴜᴘ\n"+ma+(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel))))

                        elif cmd.startswith("bcast: "):
                          if msg._from in admin:
                            tod = text.split(" ")
                            hey = text.replace(tod[0] + " ", "")
                            text = "{}".format(hey)
                            groups = dollypk.getGroupIdsJoined()
                            friends = dollypk.getAllContactIds()
                            for gr in groups:
                                data = {
                                    "type": "text",
                                    "text": " ʙʀᴏᴀᴅᴄᴀꜱᴛ ʙʏ\n      𝙋.𝙆 𝙎𝙀𝙇𝙁𝘽𝙊𝙏𝙎\n{}".format(text),
                                    "sentBy": {
                                        "label":"𝙋.𝙆°𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎ᴾʳᵒᵗᵉᶜᵗᵒʳ",
                                    "iconUrl": "https://img.alicdn.com/imgextra/i4/198820827/TB2jm7OgMFkpuFjSspnXXb4qFXa_!!198820827.gif",
                                    "linkUrl": "line://nv/profilePopup/mid=u3a4cc9a5d0da4077d7dc6cd4f405517c"
                                  }
                                }
                                dollypk.postTemplate(gr, data)
                                time.sleep(1)
                            sendTextTemplate(to, "ᴛᴇʀᴋɪʀɪᴍ {} ɢʀᴏᴜᴘ ".format(str(len(groups))))
                                
                        elif cmd == "cabut":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = dollypk.getGroup(msg.to)
                                sendTextTemplate(msg.to, "ʙʏᴇ \n       "+str(G.name))
                                dollypk.leaveGroup(msg.to)
                               
                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = dollypk.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                sendTextTemplate(msg.to, "ᴡᴀɪᴛ...")
                                sendTextTemplate(msg.to, "%.10f lumayan lah " % (get_profile_time/3))

                        elif cmd == "lurking on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['RAreadPoint'][msg.to] = msg_id
                                 Setmain['RAreadMember'][msg.to] = {}
                                 sendTextTemplate(msg.to, "☆Lurking berhasil diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurking off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['RAreadPoint'][msg.to]
                                 del Setmain['RAreadMember'][msg.to]
                                 sendTextTemplate(msg.to, "☆Lurking berhasil dinoaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['RAreadPoint']:
                                if Setmain['RAreadMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['RAreadMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(dollypk.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        dollypk.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Setmain['RAreadPoint'][msg.to]
                                        del Setmain['RAreadMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['RAreadPoint'][msg.to] = msg.id
                                    Setmain['RAreadMember'][msg.to] = {}
                                else:
                                    sendTextTemplate(msg.to, "User kosong...")
                            else:
                                sendTextTemplate(msg.to, "Ketik lurking on dulu")

                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate(msg.to, "▪ᴅɪ ᴀᴋᴛɪғᴋᴀɴ\n▪ "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n▪ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendTextTemplate(msg.to, "▪ᴅɪ ᴍᴀᴛɪᴋᴀɴ\n▪ "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n▪ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                              else:
                                  sendTextTemplate(msg.to, "▪sᴜᴅᴀʜ ᴛɪᴅᴀᴋ ᴀᴋᴛɪғ")

#===========SPAM============
                        elif cmd.startswith("cekdate: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            tanggal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                            data=r.text
                            data=json.loads(data)
                            lahir = data["data"]["lahir"]
                            usia = data["data"]["usia"]
                            ultah = data["data"]["ultah"]
                            zodiak = data["data"]["zodiak"]
                            sendTextTemplate(msg.to,"☆ I N F O R M A S I ☆\n\n"+"☆ Date Of Birth : "+lahir+"\n☆ Age : "+usia+"\n☆ Ultah : "+ultah+"\n☆ Zodiak : "+zodiak)

                        elif cmd.startswith("jumlah: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["RAlimit"] = num
                                sendTextTemplate(msg.to,"▪ᴛᴏᴛᴀʟ sᴛᴀɢ ᴅɪ ʀᴜʙᴀʜ ᴊᴀᴅɪ " +strnum)

                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                sendTextTemplate(msg.to,"▪ᴛᴏᴛᴀʟ sᴘᴀᴍᴄᴀʟʟ ᴅɪ ʀᴜʙᴀʜ ᴊᴀᴅɪ " +strnum)

                        elif cmd.startswith("stag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["RAlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                dollypk.sendMessage(msg)
                                            except Exception as e:
                                                dollypk.sendMessage(msg.to,str(e))
                                    else:
                                        sendTextTemplate(msg.to,"▪ᴊᴜᴍʟᴀʜ ᴍᴇʟᴇʙɪʜɪ 1000")
                                        
                        elif cmd == "scall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = dollypk.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                dollypk.sendMessage(msg.to, "▪ᴅᴏɴᴇ ᴍᴇɴɢᴜɴᴅᴀɴɢ {} ᴘᴀɴɢɢɪʟᴀɴ ɢʀᴏᴜᴘ".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        dollypk.acquireGroupCallRoute(to)
                                        dollypk.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        dollypk.sendText(msg.to,str(e))
                                else:
                                    sendTextTemplate(msg.to,"Jumlah melebihi batas")

                        elif 'ID line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('ID line: ','')
                              conn = dollypk.findContactsByUserid(msgs)
                              if True:
                                  dollypk.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  dollypk.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "sᴀᴍʙᴜᴛᴀɴ ᴀᴋᴛɪғ"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = dollypk.getGroup(msg.to)
                                       msgs = "▪ᴅɪ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  sendTextTemplate(msg.to, "ᴀᴋᴛɪғ\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = dollypk.getGroup(msg.to)
                                         msgs = "▪sᴀᴍʙᴜᴛᴀɴ ᴍᴀᴛɪ\n▪ᴅɪ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "▪sᴀᴍʙᴜᴛᴀɴ sᴜᴅᴀʜ ᴍᴀᴛɪ"
                                    sendTextTemplate(msg.to, "▪ᴛᴇᴡᴀs\n" + msgs)

                        elif 'Allprotect ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Allprotect ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = dollypk.getGroup(msg.to)
                                      msgs = "▪ᴘʀᴏ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ\n▪ᴅɪ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = dollypk.getGroup(msg.to)
                                      msgs = "▪ᴘʀᴏ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ\n▪ᴅɪ ɢʀᴏᴜᴘ \n▪ " +str(ginfo.name)
                                  sendTextTemplate(msg.to, "sᴇᴍᴜᴀ ᴘʀᴏ ᴀᴋᴛɪғ\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = dollypk.getGroup(msg.to)
                                         msgs = "▪ᴅᴏɴᴇ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ᴘʀᴏ\n▪ᴅɪ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         ginfo = dollypk.getGroup(msg.to)
                                         msgs = "▪ᴘʀᴏ ᴅɪ ᴍᴀᴛɪᴋᴀɴ\n▪ᴅɪ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    sendTextTemplate(msg.to, "▪ᴅᴏɴᴇ\n" + msgs)

#=========== KICKOUT ============#
                        elif ("Ajskick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in pkbots:
                                       try:
                                           G = dollypk.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           dollypk.updateGroup(G)
                                           invsend = 0
                                           Ticket = dollypk.reissueGroupTicket(msg.to)
                                           diravio.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           diravio.sendMessage(msg.to, "MANA DIA GW HABISIN")
                                           diravio.kickoutFromGroup(msg.to, [target])
                                           diravio.sendMessage(msg.to, "done bang dol reinv lagi😂")
                                           diravio.leaveGroup(msg.to)
                                           X = dollypk.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           dollypk.updateGroup(X)
                                           dollypk.inviteIntoGroup(msg.to, [mid1])
                                       except:
                                           pass

                        elif ("Kick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in pkbots:
                                       try:
                                           dollypk.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

#===========ADMIN ADD============#
                        elif ("adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜ ᴀᴅᴍɪɴ▪")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           pkbots.append(target)
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜ ʙᴏᴛ▪")
                                       except:
                                           pass

                        elif ("admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ᴀᴅᴍɪɴ▪")
                                       except:
                                           pass

                        elif ("Botdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           pkbots.remove(target)
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ᴀᴅᴍɪɴ▪")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                sebdTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛ ɴʏᴀ▪")

                        elif cmd == "admin:off" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛ ɴʏᴀ▪")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛ ɴʏᴀ▪")

                        elif cmd == "bot:off" or text.lower() == 'bot:repeat':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛ ɴʏᴀ▪")

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                sendTextTemplate(msg.to,"▪done")

                        elif cmd == "admin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = dollypk.getContact(i)
                                    dollypk.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "staff" or text.lower() == 'contact staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = dollypk.getContact(i)
                                    dollypk.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == ".mybot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in pkbots:
                                    ma = dollypk.getContact(i)
                                    dollypk.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#==========================================================================                                
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                sendTextTemplate(msg.to,"▪ɴᴏᴛᴀɢ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["MentionKick"] = False
                                sendTextTemplate(msg.to,"▪ɴᴏᴛᴀɢ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                sendTextTemplate(msg.to,"▪ᴅᴇᴛᴇᴋsɪ ᴄᴏɴᴛᴀᴄᴛ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                sendTextTemplate(msg.to,"▪ᴅᴇᴛᴇᴋsɪ ᴄᴏɴᴛᴀᴄᴛ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏʀᴇsᴘᴏɴ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏʀᴇsᴘᴏɴ ᴅɪ ᴍᴀᴛɪᴋᴀɴ▪")
                                
                        elif cmd == "responpm on" or text.lower() == 'responpm on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["arespon"] = True
                                sendTextTemplate(msg.to,"▪ʀᴇsᴘᴏɴᴘᴍ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "responpm off" or text.lower() == 'responpm off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["arespon"] = False
                                sendTextTemplate(msg.to,"▪ʀᴇsᴘᴏɴᴘᴍ ᴅɪ ᴍᴀᴛɪᴋᴀɴ▪")          

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏ ᴊᴏɪɴ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏ ᴊᴏɪɴ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ▪")
                                
                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                sendTextTemplate(msg.to,"▪ᴅᴇᴛᴇᴋsɪ sᴛɪᴄᴋᴇʀ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")            
                                
                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                sendTextTemplate(msg.to,"▪ᴅᴇᴛᴇᴋsɪ sᴛɪᴄᴋᴇʀ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")         

                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏᴀᴅᴅ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏᴀᴅᴅ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ▪")
                                
                        elif cmd == "left on" or text.lower() == 'left on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["leaveMsg"] = True
                                sendTextTemplate(msg.to,"▪ʟᴇғᴛ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "left off" or text.lower() == 'left off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["leaveMsg"] = False
                                sendTextTemplate(msg.to,"▪ʟᴇғᴛ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ▪")
                                
                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")
                                
                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                sendTextTemplate(msg.to,"▪ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ▪")          

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                sendTextTemplate(msg.to,"▪ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ▪")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                sendTextTemplate(msg.to,"▪ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ▪")

#===========CMD BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜ ʙʟᴀᴄᴋʟɪsᴛ▪")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ʙʟᴀᴄᴋʟɪsᴛ▪")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛ ɴʏᴀ▪")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛ ɴʏᴀ▪")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴᴀᴍʙᴀʜ ʙʟᴀᴄᴋʟɪsᴛ▪")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ ᴍᴇɴɢʜᴀᴘᴜs ʙʟᴀᴄᴋʟɪsᴛ▪")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛɴʏᴀ▪")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                sendTextTemplate(msg.to,"▪ᴋɪʀɪᴍ ᴄᴏɴᴛᴀᴄᴛɴʏᴀ▪")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                sendTextTemplate(msg.to,"▪ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙʟᴀᴄᴋʟɪsᴛ▪")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +dollypk.getContact(m_id).displayName + "\n"
                                sendTextTemplate(msg.to,"▪ʙʟᴀᴄᴋʟɪsᴛ ᴜsᴇʀ▪\n\n"+ma+"\n▪ᴊᴜᴍʟᴀʜ「%s」ʙʟᴀᴄᴋʟɪsᴛ ᴜsᴇʀ▪" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                sendTextTemplate(msg.to,"▪ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴛᴀʟᴋʙᴀɴ ᴜsᴇʀ▪")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +dollypk.getContact(m_id).displayName + "\n"
                                sendTextTemplate(msg.to,"??ᴛᴀʟᴋʙᴀɴ ᴜsᴇʀ▪\n\n"+ma+"\n▪ᴊᴜᴍʟᴀʜ「%s」ᴛᴀʟᴋʙᴀɴ ᴜsᴇʀ▪" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "cbl" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    sendTextTemplate(msg.to,"▪ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙʟᴀᴄᴋʟɪsᴛ▪")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = dollypk.getContact(i)
                                        dollypk.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "clearban" or text.lower() == 'clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = dollypk.getContacts(wait["blacklist"])
                              mc = "「%i」ᴜsᴇʀ ʙʟᴀᴄᴋʟɪsᴛ" % len(ragets)
                              sendTextTemplate(msg.to,"▪ᴅᴏɴᴇ \n  "    +mc)
                              
                        elif text.lower() == 'payment':
                               dollypk.sendMessage(msg.to, "ᴘᴀʏᴍᴇɴᴛ ᴠɪᴀ ʙᴀɴᴋ\nɴᴏ ʀᴇᴋ : 481901020711531\nᴀᴛᴀs ɴᴀᴍᴀ : muhazir\nʙᴀɴᴋ ʙʀɪ\n\nᴠɪᴀ ᴘᴜʟsᴀ\n08992906209"    +mc)
#===========CMD SET=============================
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate(msg.to, "▪Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  sendTextTemplate(msg.to, "▪Pesan Msg▪\n▪Pesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate(msg.to, "▪Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  sendTextTemplate(msg.to, "▪Welcome Msg▪\n▪Welcome Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  dollypk.sendMessage(msg.to, "▪Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  sendTextTemplate(msg.to, "▪Respon Msg▪\n▪Respon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set left: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set left: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate(msg.to, "▪Gagal mengganti Respon Msg")
                              else:
                                  wait["left"] = spl
                                  sendTextTemplate(msg.to, "▪Respon Left▪\n▪Respon left diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate(msg.to, "▪Gagal mengganti Spam")
                              else:
                                  Setmain["RAmessage1"] = spl
                                  sendTextTemplate(msg.to, "▪Spam Msg▪\n▪Spam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate(msg.to, "▪Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  sendTextTemplate(msg.to, "▪Sider Msg▪\n▪Sider Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪Pesan Msg▪\n▪Pesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek left":
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪left Msg▪\n▪Left Msg mu :\n\n「 " + str(wait["left"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪Welcome Msg▪\n▪Welcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪Respon Msg▪\n▪Respon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪Spam Msg▪\n▪Spam Msg mu :\n\n「 " + str(Setmain["RAmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               sendTextTemplate(msg.to, "▪Sider Msg▪\n▪Sider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")

                        elif cmd == "cek":
                            if msg._from in admin or msg._from in owner:
                               try:dollypk.inviteIntoGroup(to, [mid]);has = "OK"
                               except:has = "NOT"
                               try:dollypk.kickoutFromGroup(to, [mid]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "Sangek"
                               else:sil = "Lemas"
                               if has1 == "OK":sil1 = "Sangek"
                               else:sil1 = "Lemas"
                               dollypk.sendMessage(to, "sᴛᴀᴛᴜs:\nᴋɪᴄᴋ : {} \nɪɴᴠɪᴛᴇ : {}".format(sil1,sil))

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = dollypk.findGroupByTicket(ticket_id)
                                     dollypk.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     dollypk.sendMessage(msg.to, "Masuk : %s" % str(group.name))

    except Exception as error:
        print (error)

while True:
  try:
      Ops = dollypk.poll.fetchOperations(dollypk.revision, 50)
      for op in Ops:
        if op.type != 0:
          dollypk.revision = max(dollypk.revision, op.revision)
          bot(op)
  except Exception as E:
    E = str(E)
    if "reason=None" in E:
      print (E)
      time.sleep(60)
      restart_program()
      
